 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define POLICY_FILE "policies.txt"
#define CLAIM_FILE "claims.txt"

struct Policyholder {
    int policy_no;
    char name[50];
    float sum_insured;
};

struct Claim {
    int claim_no;
    int policy_no;
    float amount;
    char status[20];
};

void addPolicy(struct Policyholder *p, int *count) {
    printf("\nEnter Policy Number: ");
    scanf("%d", &p[*count].policy_no);

    printf("Enter Policyholder Name: ");
    scanf(" %49[^\n]", p[*count].name);

    printf("Enter Sum Insured: ");
    scanf("%f", &p[*count].sum_insured);

    if (p[*count].sum_insured <= 0) {
        printf("Invalid sum insured!\n");
        return;
    }

    FILE *fp = fopen(POLICY_FILE, "a");

    if (fp == NULL) {
        printf("Unable to open policy file!\n");
        return;
    }

    fprintf(fp, "%d|%s|%.2f\n",
            p[*count].policy_no,
            p[*count].name,
            p[*count].sum_insured);

    fclose(fp);
    (*count)++;

    printf("Policyholder added successfully!\n");
}

void addClaim(struct Claim *c, int *count) {
    printf("\nEnter Claim Number: ");
    scanf("%d", &c[*count].claim_no);

    printf("Enter Policy Number: ");
    scanf("%d", &c[*count].policy_no);

    printf("Enter Claim Amount: ");
    scanf("%f", &c[*count].amount);

    if (c[*count].amount <= 0) {
        printf("Invalid claim amount!\n");
        return;
    }

    strcpy(c[*count].status, "PENDING");

    FILE *fp = fopen(CLAIM_FILE, "a");

    if (fp == NULL) {
        printf("Unable to open claim file!\n");
        return;
    }

    fprintf(fp, "%d|%d|%.2f|%s\n",
            c[*count].claim_no,
            c[*count].policy_no,
            c[*count].amount,
            c[*count].status);

    fclose(fp);
    (*count)++;

    printf("Claim registered successfully!\n");
}

void processClaims(struct Policyholder *p, int policyCount,
                   struct Claim *c, int claimCount) {
    int i, j, found;

    FILE *fp = fopen(CLAIM_FILE, "w");

    if (fp == NULL) {
        printf("Unable to update claim file!\n");
        return;
    }

    for (i = 0; i < claimCount; i++) {
        found = 0;

        if (strcmp(c[i].status, "PENDING") != 0) {
            fprintf(fp, "%d|%d|%.2f|%s\n",
                    c[i].claim_no, c[i].policy_no,
                    c[i].amount, c[i].status);
            continue;
        }

        for (j = 0; j < policyCount; j++) {
            if (p[j].policy_no == c[i].policy_no) {
                found = 1;

                if (c[i].amount <= p[j].sum_insured) {
                    strcpy(c[i].status, "APPROVED");
                } else {
                    strcpy(c[i].status, "REJECTED");
                }

                break;
            }
        }

        if (!found) {
            strcpy(c[i].status, "REJECTED");
        }

        fprintf(fp, "%d|%d|%.2f|%s\n",
                c[i].claim_no, c[i].policy_no,
                c[i].amount, c[i].status);

        printf("Claim %d: %s\n",
               c[i].claim_no, c[i].status);
    }

    fclose(fp);
}

void displayClaims(struct Claim *c, int count) {
    int i;

    printf("\n--- Claim Details ---\n");
    printf("%-12s %-12s %-12s %-12s\n",
           "Claim No", "Policy No", "Amount", "Status");

    for (i = 0; i < count; i++) {
        printf("%-12d %-12d %-12.2f %-12s\n",
               c[i].claim_no,
               c[i].policy_no,
               c[i].amount,
               c[i].status);
    }
}

void generateReport(struct Claim *c, int count) {
    int i, approved = 0, pending = 0, rejected = 0;

    for (i = 0; i < count; i++) {
        if (strcmp(c[i].status, "APPROVED") == 0)
            approved++;
        else if (strcmp(c[i].status, "PENDING") == 0)
            pending++;
        else if (strcmp(c[i].status, "REJECTED") == 0)
            rejected++;
    }

    printf("\n--- Claim Processing Report ---\n");
    printf("Total Claims: %d\n", count);
    printf("Approved Claims: %d\n", approved);
    printf("Pending Claims: %d\n", pending);
    printf("Rejected Claims: %d\n", rejected);
}

int main(void) {
    int policyCount = 0, claimCount = 0, choice;
    int maxPolicies = 100, maxClaims = 100;

    struct Policyholder *policies =
        malloc(maxPolicies * sizeof(struct Policyholder));

    struct Claim *claims =
        malloc(maxClaims * sizeof(struct Claim));

    if (policies == NULL || claims == NULL) {
        printf("Memory allocation failed!\n");
        free(policies);
        free(claims);
        return 1;
    }

    do {
        printf("\n===== HEALTH INSURANCE CLAIM SYSTEM =====\n");
        printf("1. Add Policyholder\n");
        printf("2. Register Claim\n");
        printf("3. Process Claims\n");
        printf("4. Display Claims\n");
        printf("5. Generate Report\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");

        if (scanf("%d", &choice) != 1) {
            printf("Invalid input!\n");
            break;
        }

        switch (choice) {
            case 1:
                if (policyCount < maxPolicies)
                    addPolicy(policies, &policyCount);
                else
                    printf("Policy storage is full!\n");
                break;

            case 2:
                if (claimCount < maxClaims)
                    addClaim(claims, &claimCount);
                else
                    printf("Claim storage is full!\n");
                break;

            case 3:
                processClaims(policies, policyCount,
                              claims, claimCount);
                break;

            case 4:
                displayClaims(claims, claimCount);
                break;

            case 5:
                generateReport(claims, claimCount);
                break;

            case 6:
                printf("Exiting system. Thank you!\n");
                break;

            default:
                printf("Invalid choice! Try again.\n");
        }
    } while (choice != 6);

    free(policies);
    free(claims);

    return 0;
}
